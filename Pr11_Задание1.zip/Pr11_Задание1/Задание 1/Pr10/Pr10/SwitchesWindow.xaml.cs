﻿using System.Windows;

namespace Pr10
{
    public partial class SwitchesWindow : Window
    {
        public SwitchesWindow()
        {
            InitializeComponent();
        }

    }
}
﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;

namespace Pr10
{
    public partial class SwitchControl : UserControl
    {
        private double _rotationAngle = 0;

        public SwitchControl()
        {
            InitializeComponent();
        }

        private void Switch_MouseEnter(object sender, MouseEventArgs e)
        {
            var canvas = sender as Canvas;
            if (canvas != null)
            {
                var scaleAnimation = new DoubleAnimation(1.2, TimeSpan.FromSeconds(0.2));
                canvas.BeginAnimation(Canvas.WidthProperty, scaleAnimation);
                canvas.BeginAnimation(Canvas.HeightProperty, scaleAnimation);
            }
        }

        private void Switch_MouseLeave(object sender, MouseEventArgs e)
        {
            var canvas = sender as Canvas;
            if (canvas != null)
            {
                var scaleAnimation = new DoubleAnimation(1.0, TimeSpan.FromSeconds(0.2));
                canvas.BeginAnimation(Canvas.WidthProperty, scaleAnimation);
                canvas.BeginAnimation(Canvas.HeightProperty, scaleAnimation);
            }
        }

        private void Switch_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            var canvas = sender as Canvas;
            if (canvas != null)
            {
                _rotationAngle += 20;

                var rotateTransform = new RotateTransform(_rotationAngle);
                canvas.RenderTransform = rotateTransform;

                var animation = new DoubleAnimation(_rotationAngle - 20, _rotationAngle, TimeSpan.FromSeconds(0.3));
                rotateTransform.BeginAnimation(RotateTransform.AngleProperty, animation);
            }
        }
    }
}
﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;

namespace Pr10
{
    public partial class SwitchesWindow : Window
    {
        private double _rotationAngle = 0;

        public SwitchesWindow()
        {
            InitializeComponent();
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void Switch_MouseEnter(object sender, MouseEventArgs e)
        {
            var switchCanvas = sender as Canvas;
            if (switchCanvas != null)
            {
                var scaleAnimation = new DoubleAnimation(1.2, TimeSpan.FromSeconds(0.2));
                switchCanvas.BeginAnimation(Canvas.WidthProperty, scaleAnimation);
                switchCanvas.BeginAnimation(Canvas.HeightProperty, scaleAnimation);
            }
        }

        private void Switch_MouseLeave(object sender, MouseEventArgs e)
        {
            var switchCanvas = sender as Canvas;
            if (switchCanvas != null)
            {
                var scaleAnimation = new DoubleAnimation(1.0, TimeSpan.FromSeconds(0.2));
                switchCanvas.BeginAnimation(Canvas.WidthProperty, scaleAnimation);
                switchCanvas.BeginAnimation(Canvas.HeightProperty, scaleAnimation);
            }
        }
        private void Switch_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            var switchCanvas = sender as Canvas;
            if (switchCanvas != null)
            {
                _rotationAngle += 20;

                var rotateTransform = new RotateTransform(_rotationAngle);
                switchCanvas.RenderTransform = rotateTransform;
                var animation = new DoubleAnimation(_rotationAngle - 20, _rotationAngle, TimeSpan.FromSeconds(0.3));
                rotateTransform.BeginAnimation(RotateTransform.AngleProperty, animation);
            }
        }
    }
}
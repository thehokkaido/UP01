﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Threading;
using System.Windows.Shapes;

namespace Pr11
{
    public partial class RoadSignsWindow : Window
    {
        private FrameworkElement _selectedSign;

        public RoadSignsWindow()
        {
            InitializeComponent();
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void Sign_MouseDown(object sender, MouseButtonEventArgs e)
        {
            var sign = sender as FrameworkElement;
            if (sign != null)
            {
                ScaleTransform transform = sign.RenderTransform as ScaleTransform ?? new ScaleTransform(1, 1);
                sign.RenderTransform = transform;
                sign.RenderTransformOrigin = new Point(0.5, 0.5);

                var scaleUp = new DoubleAnimation(2.0, TimeSpan.FromSeconds(0.5));
                transform.BeginAnimation(ScaleTransform.ScaleXProperty, scaleUp);
                transform.BeginAnimation(ScaleTransform.ScaleYProperty, scaleUp);

                var moveAnimation = new DoubleAnimation(500, TimeSpan.FromSeconds(0.5));
                sign.BeginAnimation(Canvas.LeftProperty, moveAnimation);

                DispatcherTimer timer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(2) };
                timer.Tick += (s, args) =>
                {
                    timer.Stop();

                    var scaleBack = new DoubleAnimation(1.0, TimeSpan.FromSeconds(0.5));
                    transform.BeginAnimation(ScaleTransform.ScaleXProperty, scaleBack);
                    transform.BeginAnimation(ScaleTransform.ScaleYProperty, scaleBack);

                    var moveBack = new DoubleAnimation(0, TimeSpan.FromSeconds(0.5));
                    sign.BeginAnimation(Canvas.LeftProperty, moveBack);
                };
                timer.Start();
            }
        }

        private void Sign_MouseEnter(object sender, MouseEventArgs e)
        {
            if (sender is Path path && path.Fill is SolidColorBrush brush)
            {
                var newBrush = new SolidColorBrush(brush.Color);
                path.Fill = newBrush;

                var animation = new ColorAnimation(Colors.Yellow, TimeSpan.FromSeconds(0.5));
                newBrush.BeginAnimation(SolidColorBrush.ColorProperty, animation);
            }
        }

        private void Sign_MouseLeave(object sender, MouseEventArgs e)
        {
            if (sender is Path path && path.Fill is SolidColorBrush brush)
            {
                var newBrush = new SolidColorBrush(brush.Color);
                path.Fill = newBrush;

                var animation = new ColorAnimation(Colors.Red, TimeSpan.FromSeconds(0.5));
                newBrush.BeginAnimation(SolidColorBrush.ColorProperty, animation);
            }
        }
    }
}
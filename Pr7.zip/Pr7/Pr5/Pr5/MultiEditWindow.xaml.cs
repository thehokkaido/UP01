﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Pr5
{
    /// <summary>
    /// Логика взаимодействия для MultiEditWindow.xaml
    /// </summary>
    public partial class MultiEditWindow : Window
    {
        public MultiEditWindow()
        {
            InitializeComponent();
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            var textBox = sender as TextBox;
            if (textBox == null) return;

            var largeStyle = (Style)FindResource("LargeTextBoxStyle");
            var smallStyle = (Style)FindResource("SmallTextBoxStyle");

            foreach (var box in GetAllTextBoxes(textBox.Parent))
            {
                if (box == textBox)
                {
                    box.Style = largeStyle;

                    if (box.Background is SolidColorBrush brush && brush.IsFrozen)
                    {
                        box.Background = new SolidColorBrush(brush.Color);
                    }

                    var heightAnimation = new DoubleAnimation(150, TimeSpan.FromSeconds(0.3));
                    box.BeginAnimation(TextBox.HeightProperty, heightAnimation);

                    var colorAnimation = new ColorAnimation(
                        Color.FromRgb(255, 240, 180), 
                        TimeSpan.FromSeconds(0.5)
                    );
                    if (box.Background is SolidColorBrush backgroundBrush)
                    {
                        backgroundBrush.BeginAnimation(SolidColorBrush.ColorProperty, colorAnimation);
                    }
                }
                else
                {
                    box.Style = smallStyle;

                    if (box.Background is SolidColorBrush brush && brush.IsFrozen)
                    {
                        box.Background = new SolidColorBrush(brush.Color);
                    }

                    var heightAnimation = new DoubleAnimation(30, TimeSpan.FromSeconds(0.3));
                    box.BeginAnimation(TextBox.HeightProperty, heightAnimation);

                    var colorAnimation = new ColorAnimation(
                        Color.FromRgb(224, 224, 224),
                        TimeSpan.FromSeconds(0.5)
                    );
                    if (box.Background is SolidColorBrush backgroundBrush)
                    {
                        backgroundBrush.BeginAnimation(SolidColorBrush.ColorProperty, colorAnimation);
                    }
                }
            }
        }
        private IEnumerable<TextBox> GetAllTextBoxes(DependencyObject parent)
        {
            List<TextBox> boxes = new List<TextBox>();

            for (int i = 0; i < VisualTreeHelper.GetChildrenCount(parent); i++)
            {
                var child = VisualTreeHelper.GetChild(parent, i);

                if (child is TextBox textBox)
                {
                    boxes.Add(textBox);
                }
                else
                {
                    boxes.AddRange(GetAllTextBoxes(child));
                }
            }

            return boxes;
        }
    }
}
